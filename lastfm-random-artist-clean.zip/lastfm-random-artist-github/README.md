# Last.fm Random Artist for Spicetify

Add a dice button to Spotify Desktop that picks a random artist from **your Last.fm listening library** and opens Spotify search for that artist.

## Features
- Fetches all pages of `library.getartists` from Last.fm.
- Chooses uniformly among artists above your chosen playcount threshold (default: **more than 20**).
- Caches the filtered library locally for 24 hours.
- Right-clicking the dice button opens settings; saving settings clears the cached artist list.
- No Spotify API credentials are needed. This extension navigates to a search result, not necessarily the exact artist profile.

## Requirements
- Spotify Desktop with [Spicetify](https://spicetify.app/docs/getting-started) installed.
- Your Last.fm username and an API key from [Last.fm API](https://www.last.fm/api/account/create).

## Install (Windows)
1. Download `lastfmRandomArtist.js` from the latest GitHub release or the repository.
2. Copy it into `%APPDATA%\spicetify\Extensions`.
3. Run in PowerShell:

   ```powershell
   spicetify config extensions lastfmRandomArtist.js
   spicetify apply
   ```

4. Open Spotify and click the dice icon. Enter your Last.fm username, API key, and playcount threshold on first use.
5. Right-click the dice button to update settings.

For macOS/Linux, the extension folder is typically `~/.config/spicetify/Extensions/`.

## Remove

```powershell
spicetify config extensions lastfmRandomArtist.js-
spicetify apply
```

## Limitations
- Spicetify and Spotify Desktop updates can break UI integrations.
- Spotify's internal webview may block Last.fm network requests due to CORS or CSP. The extension attempts a JSONP fallback, but that can also be blocked. This release has **not been verified** across Spotify versions.
- Uses `window.prompt` for the first-time setup; some Spotify builds might restrict these dialogs.
- Spotify name search is not an exact Last.fm-to-Spotify artist matching service.
- Your Last.fm username, API key and playcount threshold are entered on first use, **not hardcoded into the extension**. The extension stores them locally in Spotify's webview storage. The API key is visible to someone with access to the application storage or network requests; never enter a private account password or shared secret.

## Development

The distributed file is plain JavaScript; no build step is needed. Test in Spotify Desktop via Spicetify DevTools (`spicetify enable-devtools`).

## License

MIT — see [LICENSE](LICENSE).

Not affiliated with Spotify, Spicetify, or Last.fm.
